package org.example;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class MyBean {
//    public int hashCode() {
//        return super.hashCode();
//    }
}
